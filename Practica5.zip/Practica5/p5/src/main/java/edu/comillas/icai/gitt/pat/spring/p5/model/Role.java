package edu.comillas.icai.gitt.pat.spring.p5.model;

public enum Role {
    USER, ADMIN
}
