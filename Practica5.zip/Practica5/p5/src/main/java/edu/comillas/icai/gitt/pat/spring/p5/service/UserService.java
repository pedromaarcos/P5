package edu.comillas.icai.gitt.pat.spring.p5.service;

import edu.comillas.icai.gitt.pat.spring.p5.entity.AppUser;
import edu.comillas.icai.gitt.pat.spring.p5.entity.Token;
import edu.comillas.icai.gitt.pat.spring.p5.model.ProfileRequest;
import edu.comillas.icai.gitt.pat.spring.p5.model.ProfileResponse;
import edu.comillas.icai.gitt.pat.spring.p5.model.RegisterRequest;
import edu.comillas.icai.gitt.pat.spring.p5.repository.TokenRepository;
import edu.comillas.icai.gitt.pat.spring.p5.repository.AppUserRepository;
import edu.comillas.icai.gitt.pat.spring.p5.util.Hashing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.Optional;

/**
 * TODO#6
 * Completa los métodos del servicio para que cumplan con el contrato
 * especificado en el interface UserServiceInterface, utilizando
 * los repositorios y entidades creados anteriormente
 */

@Service
public class UserService implements UserServiceInterface {

    @Autowired private AppUserRepository appUserRepository;
    @Autowired private TokenRepository tokenRepository;
    @Autowired private Hashing hashing;

    public Token login(String email, String password) {
        AppUser appUser = appUserRepository.findByEmail(email);
        if (appUser == null || hashing.compare(appUser.password, password) == false){
            return null;
        }

        Token token = tokenRepository.findByAppUser(appUser);
        if (token != null){
            return token;
        }

        token = new Token();
        token.appUser = appUser;
        return tokenRepository.save(token);
    }

    public AppUser authentication(String tokenId) {
        Optional<Token> token = tokenRepository.findById(tokenId);
        return token.isPresent() ? token.get().appUser : null;
    }

    public ProfileResponse profile(AppUser appUser) {
        return new ProfileResponse(
                appUser.name,
                appUser.email,
                appUser.role
        );
    }
    public ProfileResponse profile(AppUser appUser, ProfileRequest profile) {
        if (profile.name() != null) {
            appUser.name = profile.name();
        }
        if (profile.role() != null) {
            appUser.role = profile.role();
        }
        if (profile.password() != null) {
            appUser.password = hashing.hash(profile.password());
        }
        appUser = appUserRepository.save(appUser);
        return profile(appUser);
    }
    public ProfileResponse profile(RegisterRequest register) {
        AppUser appUser = new AppUser();
        appUser.name = register.name();
        appUser.email = register.email();
        appUser.role = register.role();
        appUser.password = hashing.hash(register.password());
        appUser = appUserRepository.save(appUser);
        return profile(appUser);
    }

    public void logout(String tokenId) {
        tokenRepository.deleteById(tokenId);
    }

    public void delete(AppUser appUser) {
        appUserRepository.delete(appUser);
    }

}
