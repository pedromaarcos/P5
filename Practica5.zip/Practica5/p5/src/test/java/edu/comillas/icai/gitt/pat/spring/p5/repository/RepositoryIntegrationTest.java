package edu.comillas.icai.gitt.pat.spring.p5.repository;

import edu.comillas.icai.gitt.pat.spring.p5.entity.AppUser;
import edu.comillas.icai.gitt.pat.spring.p5.entity.Token;
import edu.comillas.icai.gitt.pat.spring.p5.model.Role;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class RepositoryIntegrationTest {
    @Autowired TokenRepository tokenRepository;
    @Autowired AppUserRepository appUserRepository;

    /**
     * TODO#9
     * Completa este test de integración para que verifique
     * que los repositorios TokenRepository y AppUserRepository guardan
     * los datos correctamente, y las consultas por AppToken y por email
     * definidas respectivamente en ellos retornan el token y usuario guardados.
     */
    @Test void saveTest() {
        // Given ...
        AppUser user = new AppUser();
        user.name = "Usuario";
        user.email = "nombre@email.com";
        user.role = Role.USER;
        user.password = "aaaaaaA1";
        Token token = new Token();
        token.appUser = user;
        // When ...
        appUserRepository.save(user);
        tokenRepository.save(token);
        // Then ...
        assertTrue(appUserRepository.existsById(user.id));
        assertTrue(tokenRepository.existsById(token.id));
        AppUser user2 = appUserRepository.findByEmail("nombre@email.com");
        assertEquals(user, user2);
        Token token2 = tokenRepository.findByAppUser(user);
        assertEquals(token, token2);
    }

    /**
     * TODO#10
     * Completa este test de integración para que verifique que
     * cuando se borra un usuario, automáticamente se borran sus tokens asociados.
     */
    @Test void deleteCascadeTest() {
        // Given ...
        AppUser user = new AppUser();
        user.name = "Usuario";
        user.email = "nombre@email.com";
        user.role = Role.USER;
        user.password = "aaaaaaA1";
        Token token = new Token();
        token.appUser = user;
        appUserRepository.save(user);
        tokenRepository.save(token);
        // When ...
        appUserRepository.delete(user);
        // Then ...
        assertEquals(0, appUserRepository.count());
        assertNull(tokenRepository.findByAppUser(user));
    }
}